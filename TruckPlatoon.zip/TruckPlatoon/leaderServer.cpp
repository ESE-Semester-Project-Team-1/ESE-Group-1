#include <iostream>
#include <cstring>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <thread>
#include <queue>
#include <mutex>
//#include "message.h"

#define PORT 8080
#define FOLLOWER 1
#define CAR 0

std::mutex mu;

//class message

std::queue<message> message_receiver_queue;
std::queue<message> message_transmit_queue;

std::atomic<bool> serverRunning(true);

// Function to handle termination signal (e.g., Ctrl+C)
void signalHandler(int signal) {
    if (signal == SIGINT) {
        std::cout << "\nTermination signal received. Shutting down server...\n";
        serverRunning = false;
    }
}

// Function to set up the server and return the server socket descriptor
int setupServer() {
    int server_fd;
    struct sockaddr_in address;
    int opt = 1;

    // Create socket file descriptor
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

 /*   // Configure socket options to allow reuse of the address and port
    if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt)) < 0) {
        perror("setsockopt failed");
        close(server_fd);
        exit(EXIT_FAILURE);
    }
*/
    // Define the server's address
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);

    // Bind the socket to the specified IP and port
    if (bind(server_fd, (struct sockaddr*)&address, sizeof(address)) < 0) {
        perror("Bind failed");
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    // Start listening for incoming connections
    if (listen(server_fd, 5) < 0) {
        perror("Listen failed");
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    std::cout << "Server is set up and listening on port " << PORT << "...\n";
    return server_fd; // Return the server socket descriptor
}

void receiverModule(int sock){

    std:: lock_guard<std::mutex>lock(mu);

    // Receive data
    char buffer[1024] = {0};
    int valread = recv(sock, buffer, 1024, 0);

    if(valread == 0){
        return;
    }
    
    if (valread < 0) {
        std::cerr << "Failed to receive data!" << std::endl;
        close(sock);
        return;
    }

    // Deserialize the received data
    message msg1;
    msg1.deserialize(buffer);

    //store data in message queue
    message_receiver_queue.push(msg1);
}

void transmitterModule(int sock){

    std:: lock_guard<std::mutex>lock(mu);

    //checking the message queue for valid messages
    while (!message_transmit_queue.empty()){

        message msg = message_transmit_queue.front();
        message_transmit_queue.pop();

        if(msg.valid == 1){

            if(msg.receiverPort != FOLLOWER){
                // Send a message to the follower

                // Calculate buffer size
                size_t buffer_size = sizeof(int) * 4 + sizeof(size_t) + msg.messg.length();
                char* buffer = new char[buffer_size];

                msg.serialize(buffer);
                
                // Send the serialized data
                if (send(sock, buffer, buffer_size, 0) < 0) {
                    std::cerr << "Failed to send the message!" << std::endl;
                } else {
                    std::cout << "Message sent successfully!" << std::endl;
                }
                
                delete[] buffer;
            } else {
                std::cout << "Message not for follower, ignoring.\n";
            }
        }
    }

}

void behaviourModule(){
    std:: lock_guard<std::mutex>lock(mu);

    // Process messages from the receiver queue

    while (!message_receiver_queue.empty()) {
        
        // Get the message at the front of the queue
        message current_message = message_receiver_queue.front();
        message_receiver_queue.pop(); // Remove the processed message from the queue

        std::cout << "Processing message for recipient: " << current_message.receiverPort << "\n";

        if (current_message.valid == 1) {

            if (current_message.receiverPort == FOLLOWER) {  // Ensure it's for the follower
                
                // Check if the message is for increasing distance
                if (current_message.messg == "Request to pass") {
                    
                    current_message.messg = "Increase Distance";
                    message_transmit_queue.push(current_message); // Add to the transmit queue
                } else {
                    
                    std::cout << "Invalid command\n";
                }
            } else {
                
                std::cout << "Message not for follower, ignoring.\n";
                message_receiver_queue.push(current_message); // Add back to the queue
                break;
            }
        } else{
            std::cout << current_message.messg << " received\n";
            message_transmit_queue.pop();
            break;
        }

    }
}

// Function to handle communication with a client
void clientHandler(int client_socket) {
    

    //recieverModule
    receiverModule(client_socket);

    //behaviourModule
    behaviourModule();

    //transmitterModule
    transmitterModule(client_socket);

}

int main() {
    // Step 1: Set up the server
    int server_fd = setupServer();
    struct sockaddr_in address;
    int addrlen = sizeof(address);

    // Step 2: Accept and handle multiple clients
    while (serverRunning) {
        int new_socket = accept(server_fd, (struct sockaddr*)&address, (socklen_t*)&addrlen);
        if (new_socket < 0) {
            perror("Accept failed");
            continue;
        }
        std::cout << "New client connected\n";

        // Create a thread to handle the client
        std::thread clientThread(clientHandler, new_socket);

        // Detach the thread for independent execution
        clientThread.detach();
    }

    // Close the server socket before exiting
    close(server_fd);
    std::cout << "Server shut down successfully.\n";
    return 0;
}
