#include <iostream>
#include <cstring>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <thread>
#include <mutex>
#include <queue>
//#include "message.h"

#define PORT 8080
#define FOLLOWER 1
#define CAR 0

std::mutex mu;

//class message

message message_trasnmit_queue[1000];

int setupClientConnection(const char* ipAddress, int port) {
    int sock = 0;
    struct sockaddr_in serv_addr;

    // Create socket
    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        std::cerr << "Socket creation error\n";
        return -1;
    }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(port);

    // Convert IP address from text to binary form
    if (inet_pton(AF_INET, ipAddress, &serv_addr.sin_addr) <= 0) {
        std::cerr << "Invalid address or address not supported\n";
        return -1;
    }

    // Connect to the server
    if (connect(sock, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0) {
        std::cerr << "Connection failed\n";
        return -1;
    }

    return sock;
}


void requestPass(){

    std:: lock_guard<std::mutex>lock(mu);

    message msg1 = message("Request to pass", 0, 100, FOLLOWER, 1);
    message_trasnmit_queue[0] = msg1;

}

void transmitterModule(int sock){

    std:: lock_guard<std::mutex>lock(mu);

    //checking the message queue for valid messages
    for (int counter =0 ; counter< 1000 ; counter++){

        if(message_trasnmit_queue[counter].valid ==1){

            // Send a message to the server

            // Calculate buffer size
            size_t buffer_size = sizeof(int) * 4 + sizeof(size_t) + message_trasnmit_queue[counter].messg.length();
            char* buffer = new char[buffer_size];

            message_trasnmit_queue[counter].serialize(buffer);
            
            // Send the serialized data
            if (send(sock, buffer, buffer_size, 0) < 0) {
                std::cerr << "Failed to send the message!" << std::endl;
            } else {
                std::cout << "Message sent successfully!" << std::endl;
            }
            
            message_trasnmit_queue[counter].valid = 0;
        }
    }

}

int main() {

    // Set up client connection
    int sock = setupClientConnection("127.0.0.1", PORT);
    if (sock < 0) {
        return -1; // Exit if connection setup failed
    }

    //car request to pass platoon
    requestPass();

    std::thread t1(transmitterModule, sock);

    t1.join();
    close(sock);

    return 0;
}
