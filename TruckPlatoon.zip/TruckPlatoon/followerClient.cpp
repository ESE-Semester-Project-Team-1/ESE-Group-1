#include <iostream>
#include <cstring>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <thread>
#include <queue>
#include <mutex>
//#include "message.h"

#define PORT 8080
#define FOLLOWER 1
#define CAR 0

std::mutex mu;

//class message

std::queue<message> message_receiver_queue;

void increaseDistance(){
    std::cout << "Distance increased\n";
}

int setupClientConnection(const char* ipAddress, int port) {
    int sock = 0;
    struct sockaddr_in serv_addr;

    // Create socket
    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        std::cerr << "Socket creation error\n";
        return -1;
    }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(port);

    // Convert IP address from text to binary form
    if (inet_pton(AF_INET, ipAddress, &serv_addr.sin_addr) <= 0) {
        std::cerr << "Invalid address or address not supported\n";
        return -1;
    }

    // Connect to the server
    if (connect(sock, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0) {
        std::cerr << "Connection failed\n";
        return -1;
    }

    return sock;
}

void receiverModule(int sock){

    std:: lock_guard<std::mutex>lock(mu);

    // Receive data
    char buffer[1024] = {0};
    int valread = recv(sock, buffer, 1024, 0);
    
    if (valread < 0) {
        std::cerr << "Failed to receive data!" << std::endl;
        close(sock);
        return;
    }

    // Deserialize the received data
    message msg1;
    msg1.deserialize(buffer);

    //store data in message queue
    message_receiver_queue.push(msg1);
}

void behaviourModule(){

    std:: lock_guard<std::mutex>lock(mu);

    // Process messages in the queue
    while (!message_receiver_queue.empty()){

        message msg = message_receiver_queue.front();
        message_receiver_queue.pop();

        if (msg.valid == 1){

            if (msg.messg == "Increase Distance") {
                
                increaseDistance();

            } else {
                
                std::cout << "Invalid command\n";
            }
        }
    }
}

int main() {
    
    // Set up client connection
    int sock = setupClientConnection("127.0.0.1", PORT);
    if (sock < 0) {
        return -1; // Exit if connection setup failed
    }

    //add acknowledgement message to seperate function
    message msg = message("Acknowledgement", 0, 100, FOLLOWER, 0);
    size_t buffer_size = sizeof(int) * 4 + sizeof(size_t) + msg.messg.length();
    char* buffer = new char[buffer_size];

    msg.serialize(buffer);
    
    // Send the serialized data
    if (send(sock, buffer, buffer_size, 0) < 0) {
        std::cerr << "Failed to send the message!" << std::endl;
    } else {
        std::cout << "Message sent successfully!" << std::endl;
    }

    //recieverModule
    receiverModule(sock);

    //behaviourModule
    std::thread t1(behaviourModule);

    close(sock);

    return 0;
}
